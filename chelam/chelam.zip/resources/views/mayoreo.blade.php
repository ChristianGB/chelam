@include('header')

  <section class="hero" id="intro">
    	<div class="container">
    		<div class="row">
    		 <div class="col-md-12 text-right navicon">
    		 	<a id="nav-toggle" class="nav_slide_button" href="#"><span></span></a>
    		 </div>
    		</div>
    		<div class="row">
    			<div class="col-md-8 col-md-offset-2 text-center inner">
    				<div class="animatedParent">

					</div>
			   </div>
              </div>
              <div class="row">
                <div class="col-md-6 col-md-offset-3 text-center">
                  
                </div>
              </div>
            </div>
    </section>
    <section id="about" class="home-section color-dark bg-white">
		<div class="container marginbot-50">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="animatedParent">
					<div class="section-heading text-center animated bounceInDown">
					<img src="img/chelas/logovert_color.png" class="logo2">
					<div class="divider-header"></div>
					</div>
					</div>
				</div>
			</div>

		</div>

		<div class="container">

		
        <div class="row">
		
		
            <div class="col-lg-8 col-lg-offset-2 animatedParent">		
				<div class="text-center">
					<p>La compra minima para considerarse mayoreo es de 3 cartones de cerveza, es decir, 72.<p>
					<p>Si deseas comprar nuestras cervezas por mayoreo, mandanos un correo a <strong>ventas@chelam.com</strong> o marcanos al telefono <strong>(044-961-278-18-92)</strong> con la siguiente informacion:</p>
					<p>* Cantidad de cervezas</p>
					<p>* Especificar cuantas cervezas de cada tipo</p>
					<p>Al hacer tu pedido se te enviara un correo donde incluieremos la cantidad de cervezas y el monto a pagar con el descuento de mayoreo desglozado y la referencia de pago.</p>
					</p>
				</div>
            </div>
		

        </div>		
		</div>

	</section>
@include('footer')