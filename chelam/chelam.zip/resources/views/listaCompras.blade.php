@include('header')
 <div id="table_compra">
    	<table>
    		<tr>
    		<th>PEDIDO CHELAM</th>
    	</tr>
    	</table>
    	<table class="pedido_compra">
    	<tr>
    		<th>Cerveza Tzotzil</th>
    		<td>$45</td>
    	</tr>
    	<tr>
    		<th>Cerveza Tzotzil</th>
    		<td>$45</td>
    	</tr>
    	<tr>
    		<th>Cerveza Tzotzil</th>
    		<td>$45</td>
    	</tr>
    	<tr>
    		<th>Cerveza Tzotzil</th>
    		<td>$45</td>
    	</tr>
    	<tr>
    		<th>Cerveza Tzotzil</th>
    		<td>$45</td>
    	</tr>
    	<tr>
    		<th>Cerveza Tzotzil</th>
    		<td>$45</td>
    	</tr>
    	<tr>
    		<th>Cerveza Tzotzil</th>
    		<td>$45</td>
    	</tr>
    	<tr>
    		<th>Cerveza Tzotzil</th>
    		<td>$45</td>
    	</tr>
    </table>
    <table>
    	<tr>
    		<td>Total:</td>
    		<th>$540.00</th>
    	</tr>
    	</table>
    	<a href="#service" class="btn btn-skin btn-scroll">Confirmar pedido</a>
    </div>
	
@include('footer')