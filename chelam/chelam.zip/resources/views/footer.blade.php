<section id="works" class="logosCervezas color-dark text-center bg-white">
		<div class="container ">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="animatedParent">
						<div class="section-heading text-center">
							<h2 class="h-bold animated bounceInDown">logos de cervezas</h2>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<ul class="footer-menu">
						<li><a href="#">Inicio</a></li>
						
					</ul>
				</div>
				<div class="col-md-6 text-right">
					<p>&copy;Copyright 2015 - CHELAM</p>
					<p>Permiso Cofepris: 143300201A3330 - TODO CON MEDIDA</p>
				</div>
			</div>	
		</div>
	</footer>
    
    <script src="js/jquery.min.js"></script>	 
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
	<script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.easing.min.js"></script>	
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/stellar.js"></script>
	<script src="js/nivo-lightbox.min.js"></script>
	<script src="js/jquery-cookie-master/src/jquery.cookie.js"></script>
	
    <script src="js/custom.js"></script>
	<script src="js/css3-animate-it.js"></script>

</body>

</html>
